<?php 
	require 'vista/index_map.html'
?>