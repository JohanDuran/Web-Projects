<?php
require 'html/paginaPrincipal.html';
?>